window.addEventListener("DOMContentLoaded", event => {
    const audio = document.querySelector("audio");
    audio.volume = 1;
    audio.play();
  });
  function myfunc()
  {
      const audio = document.querySelector("audio");
    audio.volume = 1;
    audio.play();
  }
